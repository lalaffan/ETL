from utils import ConfigParamsLoader, LoadRule, DataPreprocessor
from fetch.provider_class_manager import ProviderClassManager
from ingest.ingest_class_manager import IngestClassManager
from logger import Logger  

logger = Logger().get_logger()

def run_pipeline(config_path):
    """
    Runs the data processing pipeline.

    This function orchestrates the following steps:
    1. Load configuration parameters from a JSON file.
    2. Fetch provider parameters for data retrieval.
    3. Fetch data from the API using the specified parameters.
    4. Preprocess the fetched data by replacing symbols and null values.
    5. Transform and ingest data to a specified target.

    Args:
        config_path (str): The path to the JSON configuration file.
    """

    # Step 1: Load Config Params
    config_loader = ConfigParamsLoader(config_path)
    provider_name = config_loader.get_provider_name()
    target = config_loader.get_target()

    # Step 2: Fetch Data from API
    provider_manager = ProviderClassManager(config_path)
    df = provider_manager.fetch_data(provider_name)
    logger.info("Data fetched completely!")

    # Step 3: Preprocess Data
    rule_loader = LoadRule(config_path)
    symbol_replacement = rule_loader.load_symbol_replacement()
    null_value_replacement = rule_loader.load_null_value_replacement()

    preprocessor = DataPreprocessor(symbol_replacement, null_value_replacement)
    df = preprocessor.replace_symbols(df)
    df = preprocessor.replace_null(df)
    logger.info("Data preprocessed!")

    # Step 4: Ingest Data
    ingest_manager = IngestClassManager(config_path)
    result = ingest_manager.ingest_data(df, target)
    logger.info(f"Ingestion result: {result}")

if __name__ == "__main__":
    run_pipeline('configs/electricity_sales_to_customers.json')